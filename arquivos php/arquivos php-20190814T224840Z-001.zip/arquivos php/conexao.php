<?php
$servidor = "localhost";
$usuario = "id9955640_shopbuildcacoal";
$senha = "";
$dbname = "id9955640_shopbuild";

//Criar a conexao
$mysqli = new mysqli ($servidor, $usuario, $senha, $dbname);